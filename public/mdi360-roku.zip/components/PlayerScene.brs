' Renders the activation code while unlinked, and the playlist once linked.
' Roku can play images and videos natively; HTML items (web pages and widgets)
' are skipped because Roku has no browser engine.

sub init()
    m.slide = m.top.findNode("slide")
    m.video = m.top.findNode("video")
    m.widget = m.top.findNode("widget")
    m.pairing = m.top.findNode("pairing")
    m.pairingCode = m.top.findNode("pairingCode")
    m.cover = m.top.findNode("cover")
    m.fadeAnim = m.top.findNode("fadeAnim")
    m.brandLabel = m.top.findNode("brandLabel")
    m.pairingTitle = m.top.findNode("pairingTitle")
    m.statusLabel = m.top.findNode("statusLabel")

    m.items = []
    ' All playable items of the current playlist, in order, including the ones
    ' still downloading. m.items holds only the ones ready to go on screen.
    m.allItems = []
    m.readyMap = {}
    m.index = -1
    m.revision = -1
    ' Per-TV setting sent by the server: "none" (hard cut) or "fade".
    m.transition = "none"

    m.slideTimer = CreateObject("roSGNode", "Timer")
    m.slideTimer.repeat = false
    m.slideTimer.observeField("fire", "onSlideTimer")
    m.top.appendChild(m.slideTimer)

    m.video.observeField("state", "onVideoState")
    m.video.observeField("position", "onVideoPosition")
    ' The remote is irrelevant on signage, and trick play only wastes memory.
    m.video.enableTrickPlay = false
    m.video.enableUI = false
    m.video.enableCC = false

    ' Stall watchdog: a video that stops advancing (weak Wi-Fi, slow upstream,
    ' heavy bitrate for this Roku) is resumed once and then skipped, so the
    ' playlist never freezes on a single file.
    m.videoPosition = 0
    m.videoStallTicks = 0
    m.videoRetries = 0
    m.stallTimer = CreateObject("roSGNode", "Timer")
    m.stallTimer.repeat = true
    m.stallTimer.duration = 5
    m.stallTimer.observeField("fire", "onStallCheck")
    m.top.appendChild(m.stallTimer)

    m.playlistId = invalid
    ' Payload that arrived mid-exhibition: applied only at the next boundary.
    m.pendingPayload = invalid
    m.resumeAfterApply = false
    m.report = m.top.findNode("report")

    ' Add-on de senhas: chamada em tela cheia com sinal sonoro e locucao.
    m.queue = m.top.findNode("queue")
    m.queueLabel = m.top.findNode("queueLabel")
    m.queueSector = m.top.findNode("queueSector")
    m.queueHistory = m.top.findNode("queueHistory")
    m.queueHistoryTitle = m.top.findNode("queueHistoryTitle")
    m.queueTitle = m.top.findNode("queueTitle")
    m.announce = m.top.findNode("announce")
    m.chime = m.top.findNode("chime")
    m.seenCalls = {}
    ' Chamadas aguardando a vez: uma chamada nunca corta a anterior.
    m.pendingCalls = []
    m.pendingAnnounceUrl = ""
    m.queueActive = false
    m.queueTimer = CreateObject("roSGNode", "Timer")
    m.queueTimer.repeat = false
    m.queueTimer.observeField("fire", "onQueueTimer")
    m.top.appendChild(m.queueTimer)

    ' A locucao entra depois do sinal sonoro, para nao se sobrepor a ele.
    m.announceTimer = CreateObject("roSGNode", "Timer")
    m.announceTimer.repeat = false
    m.announceTimer.duration = 1.3
    m.announceTimer.observeField("fire", "onAnnounceTimer")
    m.top.appendChild(m.announceTimer)

    m.prefetch = m.top.findNode("prefetch")
    m.prefetch.observeField("ready", "onPrefetchReady")
    m.prefetch.control = "RUN"

    m.sync = m.top.findNode("sync")
    m.widget.baseUrl = m.sync.baseUrl
    m.statusLabel.text = "Iniciando MDI 360..."
    m.sync.observeField("activationCode", "onActivationCode")
    m.sync.observeField("payload", "onPayload")
    m.sync.observeField("statusText", "onStatusText")
    m.report.baseUrl = m.sync.baseUrl
    m.report.control = "RUN"
    m.sync.control = "RUN"

    m.top.setFocus(true)
end sub

sub onStatusText()
    m.statusLabel.text = m.sync.statusText
end sub

sub onActivationCode()
    code = m.sync.activationCode
    m.pairingCode.text = code
    if code <> "" then showPairing(true)
end sub

sub showPairing(visible as boolean)
    ' A ticket call owns the screen until its timer ends.
    if m.queueActive = true and visible then return
    m.pairing.visible = visible
    if visible
        m.slide.opacity = 0
        m.video.visible = false
        m.video.control = "stop"
        m.widget.visible = false
        if m.fadeAnim <> invalid then m.fadeAnim.control = "stop"
        if m.cover <> invalid then m.cover.opacity = 0
    end if
end sub

sub onPayload()
    payload = m.sync.payload
    if payload = invalid then return

    ' A ticket call never waits for the current file: it takes over the screen
    ' immediately, which is the whole point of the queue add-on.
    handleQueueCall(payload)

    ' Nothing on screen yet (or playlist emptied): apply right away.
    if m.items.Count() = 0
        applyPayload(payload)
        return
    end if

    ' Playlist gone: stop immediately, that is the expected behaviour.
    if payload.playlist = invalid or payload.playlist.items = invalid or payload.playlist.items.Count() = 0
        m.pendingPayload = invalid
        applyPayload(payload)
        return
    end if

    ' Something is playing: hold the new payload until the current file ends,
    ' so the content is never cut in the middle.
    if changesPlayback(payload)
        m.pendingPayload = payload
    else
        applyPayload(payload)
    end if
end sub

' True when the payload would change what/how the TV plays (playlist revision,
' global audio switch or transition setting).
function changesPlayback(payload as object) as boolean
    if payload.playlist <> invalid and payload.playlist.revision <> m.revision then return true
    if payload.device <> invalid
        audio = true
        if payload.device.audioEnabled = false then audio = false
        if audio <> m.audioEnabled then return true
        if payload.device.transitionEffect <> invalid
            newTransition = "none"
            if payload.device.transitionEffect = "fade" then newTransition = "fade"
            if newTransition <> m.transition then return true
        end if
    end if
    return false
end function

sub applyPayload(payload as object)
    m.pendingPayload = invalid

    ' Global audio switch of this screen. When the TV is muted in the Studio,
    ' every video plays silently no matter what the playlist item asks for.
    m.audioEnabled = true
    if payload.device <> invalid and payload.device.audioEnabled = false then m.audioEnabled = false
    if payload.device <> invalid and payload.device.transitionEffect <> invalid
        if payload.device.transitionEffect = "fade"
            m.transition = "fade"
        else
            m.transition = "none"
        end if
    end if

    ' Whitelabel: the splash text and brand name come from the customer account.
    if payload.branding <> invalid
        if payload.branding.name <> invalid and payload.branding.name <> "" then m.brandLabel.text = payload.branding.name
        if payload.branding.splashText <> invalid and payload.branding.splashText <> "" then m.pairingTitle.text = payload.branding.splashText
        if payload.branding.color <> invalid and payload.branding.color <> "" then m.widget.brandColor = hexToRokuColor(payload.branding.color)
    end if

    if payload.playlist = invalid or payload.playlist.items = invalid or payload.playlist.items.Count() = 0
        m.items = []
        m.allItems = []
        m.readyMap = {}
        if m.prefetch <> invalid then m.prefetch.urls = []
        ' Forget the revision: when the same playlist comes back (unchanged
        ' revision) we must accept it again instead of ignoring it below.
        m.revision = -1
        m.pairingTitle.text = "Aguardando conteudo"
        m.pairingCode.text = ""
        m.statusLabel.text = "Tela vinculada. Publique uma playlist no Studio."
        showPairing(true)
        return
    end if

    m.playlistId = payload.playlist.id
    if payload.playlist.revision = m.revision
        ' Only settings changed: keep the list and just continue playing.
        if m.resumeAfterApply
            m.resumeAfterApply = false
            advanceItem()
        end if
        return
    end if
    m.revision = payload.playlist.revision

    playable = []
    for each item in payload.playlist.items
        kind = item.kind
        if kind = "widget"
            ' Widgets are drawn natively by WidgetView — no browser needed.
            playable.push(item)
        else if (kind = "image" or kind = "video") and item.url <> invalid and item.url <> ""
            playable.push(item)
        end if
    end for

    m.allItems = playable

    ' Ask the prefetch task about the files of this playlist. Anything that is
    ' not confirmed yet stays out of the rotation; the TV keeps playing what it
    ' already has and the file joins its position once it is ready.
    urls = []
    for each item in playable
        if item.kind <> "widget" and item.url <> invalid and item.url <> "" then urls.push(item.url)
    end for
    ' Drop files that left the playlist (deleted in the Studio) from the map,
    ' so they are never shown again and are re-verified if they come back.
    fresh = {}
    for each url in urls
        if m.readyMap[url] = true then fresh[url] = true
    end for
    m.readyMap = fresh
    m.prefetch.ready = fresh
    m.prefetch.urls = urls

    m.items = readyItems()
    m.index = -1
    if m.items.Count() > 0
        showPairing(false)
        playNext()
    else
        m.pairingCode.text = ""
        m.statusLabel.text = "Baixando conteudo para esta tela..."
        showPairing(true)
    end if
end sub

' Items whose file is already confirmed on this TV (widgets need no download).
function readyItems() as object
    result = []
    for each item in m.allItems
        if item.kind = "widget"
            result.push(item)
        else if item.url <> invalid and m.readyMap[item.url] = true
            result.push(item)
        end if
    end for
    return result
end function

' A file finished downloading/became available: it enters the rotation in its
' own playlist position, without interrupting whatever is on screen.
sub onPrefetchReady()
    ready = m.prefetch.ready
    if ready = invalid then return
    m.readyMap = ready

    currentId = invalid
    if m.index >= 0 and m.index < m.items.Count() then currentId = m.items[m.index].id

    m.items = readyItems()

    ' Keep pointing at the item currently on screen so the new file only shows
    ' up when its turn comes.
    if currentId <> invalid
        for i = 0 to m.items.Count() - 1
            if m.items[i].id = currentId
                m.index = i
                return
            end if
        end for
        m.index = -1
        return
    end if

    if m.items.Count() > 0 and m.index < 0
        showPairing(false)
        playNext()
    end if
end sub

sub playNext()
    ' A newer playlist / settings payload waited for this exact moment.
    if m.pendingPayload <> invalid
        pending = m.pendingPayload
        m.pendingPayload = invalid
        m.resumeAfterApply = true
        applyPayload(pending)
        m.resumeAfterApply = false
        return
    end if
    advanceItem()
end sub

sub advanceItem()
    ' Never draw content over an active ticket call.
    if m.queueActive = true then return
    if m.items.Count() = 0 then return
    m.index = (m.index + 1) mod m.items.Count()
    item = m.items[m.index]

    ' Tell the server what went on screen (playback reports / live view).
    if m.report <> invalid
        m.report.report = {
            playlistId: m.playlistId,
            mediaAssetId: item.mediaAssetId,
            durationMs: item.durationMs
        }
    end if

    if item.kind <> "video" and m.stallTimer <> invalid then m.stallTimer.control = "stop"

    ' Blackout before swapping: hides the Video node's file name/spinner and
    ' gives the fade something to fade from.
    if m.fadeAnim <> invalid then m.fadeAnim.control = "stop"
    if item.kind = "video" or m.transition = "fade"
        m.cover.opacity = 1
    else
        m.cover.opacity = 0
    end if

    if item.kind = "widget"
        m.video.control = "stop"
        m.video.visible = false
        m.slide.opacity = 0
        m.widget.item = {
            widgetType: item.widgetType,
            widgetConfig: item.widgetConfig,
            name: item.name,
        }
        m.widget.visible = true
        duration = 15000
        if item.durationMs <> invalid and item.durationMs > 1000 then duration = item.durationMs
        m.slideTimer.duration = duration / 1000.0
        m.slideTimer.control = "start"
        revealContent()
    else if item.kind = "video"
        ' A single-video playlist replays the same node, so reset the player
        ' before loading the content again — otherwise it stays on "finished".
        m.video.control = "stop"
        content = CreateObject("roSGNode", "ContentNode")
        content.url = item.url
        content.streamformat = streamFormatFor(item.url)
        ' No title / no description: Roku would flash the file name on screen.
        content.title = ""
        m.video.content = content
        content.StreamBitrate = 0
        content.StreamQualities = ["HD"]
        content.StreamContentIDs = [item.id]
        m.video.mute = (item.isMuted = true) or (m.audioEnabled = false)
        m.slide.opacity = 0
        m.widget.visible = false
        m.video.visible = true
        m.videoPosition = 0
        m.videoStallTicks = 0
        m.video.control = "play"
        m.stallTimer.control = "start"
    else
        m.video.control = "stop"
        m.video.visible = false
        m.widget.visible = false
        m.slide.uri = item.url
        m.slide.opacity = 1
        duration = 10000
        if item.durationMs <> invalid and item.durationMs > 1000 then duration = item.durationMs
        m.slideTimer.duration = duration / 1000.0
        m.slideTimer.control = "start"
        revealContent()
    end if
end sub

' Removes the black curtain — instantly, or with a soft fade when the customer
' enabled the transition for this TV.
sub revealContent()
    if m.cover = invalid then return
    if m.transition = "fade" and m.fadeAnim <> invalid
        m.cover.opacity = 1
        m.fadeAnim.control = "start"
    else
        m.cover.opacity = 0
    end if
end sub

sub onSlideTimer()
    playNext()
end sub

' ---------------------------------------------------------------- senhas ----

' Enfileira as chamadas recebidas no payload (nunca vistas antes) e inicia a
' primeira se a tela estiver livre. Chamadas em sequencia formam fila.
sub handleQueueCall(payload as object)
    calls = payload.queueCalls
    if calls = invalid or Type(calls) <> "roArray"
        calls = []
        if payload.queueCall <> invalid then calls.push(payload.queueCall)
    end if
    if calls.Count() = 0 then return

    added = false
    for each call in calls
        if call <> invalid and call.id <> invalid and call.id <> ""
            if m.seenCalls[call.id] <> true
                m.seenCalls[call.id] = true
                m.pendingCalls.push(call)
                added = true
            end if
        end if
    end for

    if added and m.queueActive <> true then startNextCall()
end sub

' Coloca na tela a proxima chamada da fila (se houver).
sub startNextCall()
    if m.pendingCalls.Count() = 0 then return
    call = m.pendingCalls.Shift()
    if call = invalid then return

    seconds = 20
    if call.displaySeconds <> invalid and call.displaySeconds > 4 then seconds = call.displaySeconds

    ' Stop whatever is on screen right now.
    if m.slideTimer <> invalid then m.slideTimer.control = "stop"
    if m.stallTimer <> invalid then m.stallTimer.control = "stop"
    m.video.control = "stop"
    m.video.visible = false
    m.widget.visible = false
    m.slide.opacity = 0
    m.pairing.visible = false
    if m.cover <> invalid then m.cover.opacity = 0

    label = ""
    if call.label <> invalid then label = call.label
    m.queueLabel.text = label
    if call.sectorName <> invalid and call.sectorName <> ""
        m.queueSector.text = call.sectorName
    else
        m.queueSector.text = ""
    end if
    showQueueHistory(call)
    m.queue.visible = true
    m.queueActive = true

    ' Sinal sonoro: MP3 embarcado no canal (o som de sistema do Roku depende de
    ' uma preferencia da TV e por isso nao era confiavel).
    beep()

    ' Locucao: o Roku nao tem sintese de voz, entao o servidor entrega um MP3
    ' pronto com "setor + senha". Toca logo depois do sinal sonoro.
    m.announceTimer.control = "stop"
    m.announce.control = "stop"
    m.pendingAnnounceUrl = ""
    if call.audioUrl <> invalid and call.audioUrl <> ""
        m.pendingAnnounceUrl = m.sync.baseUrl + call.audioUrl
        m.announceTimer.control = "start"
    end if

    m.queueTimer.control = "stop"
    m.queueTimer.duration = seconds
    m.queueTimer.control = "start"
end sub

' Dois toques curtos antes da locucao. Usa um Audio node com MP3 do pacote:
' Mostra as ultimas senhas chamadas antes desta (ex.: "A011   A010   A009").
sub showQueueHistory(call as object)
    if m.queueHistory = invalid then return
    parts = []
    if call.history <> invalid and Type(call.history) = "roArray"
        for each item in call.history
            if item <> invalid and item.label <> invalid and item.label <> ""
                parts.push(item.label)
            end if
            if parts.Count() >= 4 then exit for
        end for
    end if

    if parts.Count() = 0
        m.queueHistory.text = ""
        m.queueHistory.visible = false
        if m.queueHistoryTitle <> invalid then m.queueHistoryTitle.visible = false
        return
    end if

    text = ""
    for each part in parts
        if text <> "" then text = text + "     "
        text = text + part
    end for
    m.queueHistory.text = text
    m.queueHistory.visible = true
    if m.queueHistoryTitle <> invalid then m.queueHistoryTitle.visible = true
end sub

' Dois toques curtos antes da locucao. Usa um Audio node com MP3 do pacote:
' funciona mesmo quando os efeitos sonoros do Roku estao desligados e nao
' bloqueia a thread de render (o sleep antigo travava a animacao da tela).
sub beep()
    if m.chime = invalid then return
    content = CreateObject("roSGNode", "ContentNode")
    content.url = "pkg:/audio/chime.mp3"
    content.streamformat = "mp3"
    m.chime.control = "stop"
    m.chime.content = content
    m.chime.control = "play"
end sub

' Hora da locucao: o sinal sonoro ja terminou.
sub onAnnounceTimer()
    if m.pendingAnnounceUrl = "" then return
    content = CreateObject("roSGNode", "ContentNode")
    content.url = m.pendingAnnounceUrl
    content.streamformat = "mp3"
    m.announce.control = "stop"
    m.announce.content = content
    m.announce.control = "play"
end sub

' The call is over: show the next one in line, or resume the playlist.
sub onQueueTimer()
    m.queueActive = false
    m.announce.control = "stop"
    m.announceTimer.control = "stop"
    m.pendingAnnounceUrl = ""

    if m.pendingCalls.Count() > 0
        startNextCall()
        return
    end if

    m.queue.visible = false

    if m.items.Count() > 0
        showPairing(false)
        playNext()
    else
        showPairing(true)
    end if
end sub

sub onVideoPosition()
    ' Any forward movement means the stream is healthy again.
    if m.video.position > m.videoPosition
        m.videoPosition = m.video.position
        m.videoStallTicks = 0
    end if
end sub

' Runs every 5s while a video is on screen.
sub onStallCheck()
    state = m.video.state
    if state <> "playing" and state <> "buffering" then return

    m.videoStallTicks = m.videoStallTicks + 1
    ' 4 ticks = ~20s with no progress at all.
    if m.videoStallTicks < 4 then return

    m.videoStallTicks = 0
    if m.videoRetries < 1
        ' One resume attempt from where it stopped before giving up.
        m.videoRetries = m.videoRetries + 1
        m.statusLabel.text = "Rede lenta: retomando o video..."
        resume = m.videoPosition
        m.video.control = "stop"
        m.video.seek = resume
        m.video.control = "play"
    else
        m.videoRetries = 0
        m.stallTimer.control = "stop"
        playNext()
    end if
end sub

sub onVideoState()
    state = m.video.state
    if state = "playing"
        m.videoRetries = 0
        ' Only now the first frame is on screen: safe to lift the curtain.
        revealContent()
    end if
    if state = "finished" or state = "error"
        if m.stallTimer <> invalid then m.stallTimer.control = "stop"
        m.videoRetries = 0
        playNext()
    end if
end sub

' Roku needs the container format up front; our library stores MP4/WebM/HLS.
function streamFormatFor(url as string) as string
    lower = LCase(url)
    if Instr(1, lower, ".m3u8") > 0 then return "hls"
    if Instr(1, lower, ".mpd") > 0 then return "dash"
    if Instr(1, lower, ".mkv") > 0 then return "mkv"
    if Instr(1, lower, ".ts") > 0 then return "ts"
    ' MOV/WebM containers are read by Roku's MP4 demuxer when the video track
    ' is H.264/H.265, which is what our library produces.
    return "mp4"
end function

' "#3B82F6" -> "0x3B82F6FF"
function hexToRokuColor(hex as string) as string
    clean = hex
    if Left(clean, 1) = "#" then clean = Mid(clean, 2)
    if Len(clean) <> 6 then return "0x3B82F6FF"
    return "0x" + UCase(clean) + "FF"
end function

' Signage screens ignore the remote, except for the back button on the root scene.
function onKeyEvent(key as string, press as boolean) as boolean
    return press
end function